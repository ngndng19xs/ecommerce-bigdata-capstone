-- =====================================================================
-- SETUP: tạo database và các bảng dùng cho benchmark (Spark SQL, bảng định dạng Hive)
-- Placeholder do bench.sh thay: __DB__  __BASE__  __REPLICAS__
-- Schema đích theo đặc tả mục 11.1:
--   event_time, event_date, user_session, user_id, event_type, product_id,
--   category, brand, price
-- =====================================================================
SET spark.sql.session.timeZone = UTC;
SET spark.sql.shuffle.partitions = 8;
SET hive.exec.dynamic.partition = true;
SET hive.exec.dynamic.partition.mode = nonstrict;

CREATE DATABASE IF NOT EXISTS __DB__;
USE __DB__;

-- 1. Bảng ngoài trỏ vào thư mục CSV gốc (toàn bộ cột là chuỗi)
DROP TABLE IF EXISTS events_csv_raw;
CREATE EXTERNAL TABLE events_csv_raw (
  event_time STRING, event_type STRING, product_id STRING, category_id STRING,
  category_code STRING, brand STRING, price STRING, user_id STRING, user_session STRING
)
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE
LOCATION '__BASE__/raw_csv'
TBLPROPERTIES ('skip.header.line.count' = '1');

-- 2. Bảng văn bản (CSV) làm đường cơ sở. REPLICAS > 1 thì nhân bản dữ liệu mẫu:
--    mỗi bản sao lùi sang 1 ngày sau và đổi user_session, user_id (dữ liệu giả để đo hiệu năng)
DROP TABLE IF EXISTS events_csv_txt;
CREATE TABLE events_csv_txt
ROW FORMAT DELIMITED FIELDS TERMINATED BY ','
STORED AS TEXTFILE AS
SELECT
  concat(from_unixtime(unix_timestamp(regexp_replace(r.event_time, ' UTC$', ''), 'yyyy-MM-dd HH:mm:ss')
         + x.rep * 86400, 'yyyy-MM-dd HH:mm:ss'), ' UTC') AS event_time,
  r.event_type, r.product_id, r.category_id, r.category_code, r.brand, r.price,
  CASE WHEN x.rep = 0 THEN r.user_id      ELSE concat(r.user_id, '_', x.rep)      END AS user_id,
  CASE WHEN x.rep = 0 THEN r.user_session ELSE concat(r.user_session, '_', x.rep) END AS user_session
FROM events_csv_raw r
CROSS JOIN (SELECT explode(sequence(0, __REPLICAS__ - 1)) AS rep) x
WHERE r.event_time <> 'event_time';

-- 3. View chuẩn hóa theo đặc tả: UTC, brand/category thiếu -> 'unknown', loại phiên thiếu
CREATE OR REPLACE VIEW events_csv AS
SELECT
  t.ts                                  AS event_time,
  to_date(t.ts)                         AS event_date,
  t.user_session, t.user_id, t.event_type, t.product_id,
  CASE WHEN t.category_code IS NULL OR t.category_code = '' THEN 'unknown' ELSE t.category_code END AS category,
  CASE WHEN t.brand         IS NULL OR t.brand         = '' THEN 'unknown' ELSE t.brand         END AS brand,
  CAST(t.price AS DOUBLE)               AS price
FROM (SELECT CAST(regexp_replace(event_time, ' UTC$', '') AS TIMESTAMP) AS ts, * FROM events_csv_txt) t
WHERE t.user_session IS NOT NULL AND t.user_session <> '' AND t.ts IS NOT NULL;

-- 4. Parquet không phân vùng
DROP TABLE IF EXISTS events_pq;
CREATE TABLE events_pq STORED AS PARQUET AS
SELECT event_time, event_date, user_session, user_id, event_type, product_id, category, brand, price
FROM events_csv;

-- 5. Parquet phân vùng theo event_date (mỗi ngày gom vào ít file)
DROP TABLE IF EXISTS events_pq_part;
CREATE TABLE events_pq_part (
  event_time TIMESTAMP, user_session STRING, user_id STRING, event_type STRING,
  product_id STRING, category STRING, brand STRING, price DOUBLE
)
PARTITIONED BY (event_date DATE)
STORED AS PARQUET;

INSERT OVERWRITE TABLE events_pq_part PARTITION (event_date)
SELECT event_time, user_session, user_id, event_type, product_id, category, brand, price, event_date
FROM events_csv
DISTRIBUTE BY event_date;

-- 6. Đối chiếu số dòng và số phiên giữa 3 định dạng (phải bằng nhau)
SELECT 'events_csv'      AS tbl, COUNT(*) AS n_rows, COUNT(DISTINCT user_session) AS n_sessions FROM events_csv
UNION ALL
SELECT 'events_pq'       AS tbl, COUNT(*) AS n_rows, COUNT(DISTINCT user_session) AS n_sessions FROM events_pq
UNION ALL
SELECT 'events_pq_part'  AS tbl, COUNT(*) AS n_rows, COUNT(DISTINCT user_session) AS n_sessions FROM events_pq_part;
