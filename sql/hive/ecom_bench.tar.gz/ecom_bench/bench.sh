#!/usr/bin/env bash
# =====================================================================
# Benchmark funnel / session / brand trên Spark SQL và kiểm thử Hive (TV2)
# Dùng:  ./bench.sh setup | build | run | summary | sizes | hive | all | clean
# Biến môi trường (đều có giá trị mặc định):
#   CSV_SRC (đường dẫn sample_20k.csv)  REPLICAS (nhân bản dữ liệu mẫu)  D1 D2
#   RUNS (số lần đo)  CORES  DRIVER_MEM  DB  WORK
#   T_CSV T_PQ T_PQP T_SF (tên bảng, đổi khi nối với bảng thật của TV1)
# =====================================================================
WORK="${WORK:-$HOME/ecom_bench_work}"
DB="${DB:-ecom_bench}"
CSV_SRC="${CSV_SRC:-$HOME/sample_20k.csv}"
REPLICAS="${REPLICAS:-1}"
D1="${D1:-2019-11-01}"
D2="${D2:-$(date -d "$D1 +$((REPLICAS-1)) days" +%F)}"
RUNS="${RUNS:-3}"
CORES="${CORES:-2}"
DRIVER_MEM="${DRIVER_MEM:-1g}"
T_CSV="${T_CSV:-events_csv}"
T_PQ="${T_PQ:-events_pq}"
T_PQP="${T_PQP:-events_pq_part}"
T_SF="${T_SF:-session_funnel_pq}"

HERE="$(cd "$(dirname "$0")" && pwd)"
BASE="file://$WORK/data"
OUT="$WORK/out"
TMP="$WORK/tmp"
RESULTS="$OUT/results.csv"
QUERIES="q1_funnel_overall q2_funnel_by_day q3_session_events q4_session_duration q5_brand_methodA q6_brand_scan"
# Trước tối ưu: cấu hình mặc định của Spark. Sau tối ưu: AQE bật, số partition shuffle nhỏ.
BASE_OPTS="--conf spark.sql.shuffle.partitions=200 --conf spark.sql.adaptive.enabled=false"
OPT_OPTS="--conf spark.sql.shuffle.partitions=8 --conf spark.sql.adaptive.enabled=true --conf spark.sql.adaptive.coalescePartitions.enabled=true"
export SPARK_LOCAL_IP="${SPARK_LOCAL_IP:-127.0.0.1}"

mkdir -p "$WORK/data/raw_csv" "$OUT" "$TMP"
cd "$WORK" || exit 1     # luôn chạy cùng một thư mục để dùng chung metastore cục bộ

render() {  # render <file_vao> <file_ra> <bang_su_kien> <bang_session_funnel>
  sed -e "s#__DB__#$DB#g" -e "s#__EVENTS__#$3#g" -e "s#__SF__#$4#g" \
      -e "s#__D1__#$D1#g" -e "s#__D2__#$D2#g" \
      -e "s#__BASE__#$BASE#g" -e "s#__REPLICAS__#$REPLICAS#g" "$1" > "$2"
}

run_spark() {  # run_spark "<tuy_chon_conf>" <file.sql>
  spark-sql -S --master "local[$CORES]" --driver-memory "$DRIVER_MEM" \
    --hiveconf hive.cli.print.header=true $1 -f "$2"
}

init_results() { [ -s "$RESULTS" ] || echo "scenario,query,run,seconds,rc,md5" > "$RESULTS"; }

timed_run() {  # timed_run <kich_ban> <nhan_query> <file.sql> "<opts>" <lan>
  local scen="$1" q="$2" f="$3" opts="$4" r="$5"
  local o="$OUT/${scen}_${q}_r${r}"
  local t0 t1 sec rc md5
  t0=$(date +%s.%N)
  run_spark "$opts" "$f" > "$o.out" 2> "$o.err"
  rc=$?
  t1=$(date +%s.%N)
  sec=$(awk -v a="$t0" -v b="$t1" 'BEGIN{printf "%.2f", b-a}')
  md5=$(md5sum < "$o.out" | cut -c1-8)
  echo "$scen,$q,$r,$sec,$rc,$md5" >> "$RESULTS"
  echo "  [$scen] $q lan $r: ${sec}s (rc=$rc)"
}

cmd_setup() {
  [ -f "$CSV_SRC" ] || { echo "Khong thay file $CSV_SRC (dat bien CSV_SRC)"; exit 1; }
  echo ">> Chuan bi CSV (bo ky tu CR va BOM) -> $WORK/data/raw_csv/"
  tr -d '\r' < "$CSV_SRC" | sed '1s/^\xEF\xBB\xBF//' > "$WORK/data/raw_csv/sample.csv"
  render "$HERE/setup.sql" "$TMP/setup.sql" x x
  echo ">> Tao database va bang (REPLICAS=$REPLICAS, ngay $D1 -> $D2)"
  run_spark "$BASE_OPTS" "$TMP/setup.sql" | tee "$OUT/setup.out"
}

cmd_build() {
  local RESULTS="$OUT/results_build.csv"   # thoi gian dung bang luu rieng, khong lan vao ket qua benchmark
  init_results
  echo ">> Dung session_funnel bang 3 lop window (chuan doi chieu)"
  render "$HERE/queries/q0a_build_sf_window.sql" "$TMP/q0a.sql" "$T_PQP" "$T_SF"
  timed_run build q0a_window "$TMP/q0a.sql" "$BASE_OPTS" 1
  echo ">> Dung session_funnel bang 1 phep gop (toi uu)"
  render "$HERE/queries/q0b_build_sf_agg.sql" "$TMP/q0b.sql" "$T_PQP" "$T_SF"
  timed_run build q0b_agg "$TMP/q0b.sql" "$OPT_OPTS" 1
  echo ">> Doi chieu hai cach dung (mismatched va missing_in_agg phai = 0)"
  render "$HERE/queries/q0c_verify_sf.sql" "$TMP/q0c.sql" "$T_PQP" "$T_SF"
  run_spark "$OPT_OPTS" "$TMP/q0c.sql" | tee "$OUT/verify_sf.out"
  echo ">> Thoi gian dung bang (giay) luu o $RESULTS"
  cat "$RESULTS"
}

cmd_run() {
  [ -s "$RESULTS" ] && mv "$RESULTS" "$OUT/results_$(date +%Y%m%d_%H%M%S).csv.bak"
  init_results
  echo ">> Do thoi gian khoi dong spark-sql"
  render "$HERE/queries/noop.sql" "$TMP/noop.sql" x x
  for r in $(seq 1 "$RUNS"); do timed_run startup noop "$TMP/noop.sql" "$BASE_OPTS" "$r"; done

  local have_sf=1
  echo "USE $DB; SELECT COUNT(*) FROM $T_SF;" > "$TMP/chk.sql"
  run_spark "" "$TMP/chk.sql" > /dev/null 2>&1 || { have_sf=0; echo "!! Chua co $T_SF: bo qua kich ban D (chay ./bench.sh build truoc)"; }

  for q in $QUERIES; do
    lab="${q%%_*}"
    echo ">> $q"
    for spec in "A_csv:$T_CSV" "B_parquet:$T_PQ" "C_parquet_partitioned:$T_PQP"; do
      scen="${spec%%:*}"; tbl="${spec#*:}"
      render "$HERE/queries/$q.sql" "$TMP/${scen}_$lab.sql" "$tbl" "$T_SF"
      for r in $(seq 1 "$RUNS"); do timed_run "$scen" "$lab" "$TMP/${scen}_$lab.sql" "$BASE_OPTS" "$r"; done
    done
    if [ "$have_sf" = 1 ]; then
      f="$HERE/queries/${q}_opt.sql"; [ -f "$f" ] || f="$HERE/queries/$q.sql"
      render "$f" "$TMP/D_optimized_$lab.sql" "$T_PQP" "$T_SF"
      for r in $(seq 1 "$RUNS"); do timed_run D_optimized "$lab" "$TMP/D_optimized_$lab.sql" "$OPT_OPTS" "$r"; done
    fi
  done
  cmd_summary
}

cmd_summary() {
  python3 - "$RESULTS" "$OUT/summary.md" << 'PY'
import sys, csv, statistics
from collections import defaultdict
rows = list(csv.DictReader(open(sys.argv[1])))
times = defaultdict(list); md5 = defaultdict(set); fails = defaultdict(int)
for r in rows:
    k = (r['scenario'], r['query'])
    if r['rc'] != '0':
        fails[k] += 1; continue
    times[k].append(float(r['seconds'])); md5[k].add(r['md5'])
startup = statistics.median(times[('startup', 'noop')]) if times[('startup', 'noop')] else 0.0
scens = ['A_csv', 'B_parquet', 'C_parquet_partitioned', 'D_optimized']
names = {'A_csv': 'A: CSV', 'B_parquet': 'B: Parquet', 'C_parquet_partitioned': 'C: Parquet + partition', 'D_optimized': 'D: C + toi uu'}
qs = sorted({r['query'] for r in rows if r['query'].startswith('q') and r['scenario'] in scens})
def med(s, q):
    v = times.get((s, q)); 
    return max(statistics.median(v) - startup, 0.0) if v else None
out = []
out.append("Thoi gian khoi dong spark-sql (da tru khoi bang): %.1f giay" % startup)
out.append("")
out.append("| Query | " + " | ".join(names[s] for s in scens) + " | Tang toc D so voi A | Ket qua giong nhau |")
out.append("|---|" + "---|" * (len(scens) + 2))
for q in qs:
    vals = [med(s, q) for s in scens]
    cells = ["%.1f" % v if v is not None else "-" for v in vals]
    sp = "%.1fx" % (vals[0] / vals[3]) if vals[0] and vals[3] else "-"
    allmd5 = set()
    for s in scens: allmd5 |= md5.get((s, q), set())
    same = "co" if len(allmd5) == 1 else ("khong (%d dang)" % len(allmd5) if allmd5 else "-")
    out.append("| %s | %s | %s | %s |" % (q, " | ".join(cells), sp, same))
bad = [(k, v) for k, v in fails.items() if k[0] != 'startup']
if bad:
    out.append("")
    out.append("Cac lan chay loi (rc khac 0): " + ", ".join("%s/%s=%d" % (k[0], k[1], v) for k, v in bad) + ". Xem file .err trong thu muc out.")
text = "\n".join(out)
print(text)
open(sys.argv[2], 'w').write(text + "\n")
PY
}

cmd_sizes() {
  for t in events_csv_txt "$T_PQ" "$T_PQP" "$T_SF"; do
    echo "USE $DB; DESCRIBE FORMATTED $t;" > "$TMP/d.sql"
    loc=$(run_spark "" "$TMP/d.sql" 2>/dev/null | awk -F'\t' '$1 ~ /^Location/ {print $2; exit}')
    case "$loc" in
      file:*) printf "%-22s %s  " "$t" "$loc"; du -sh "${loc#file:}" | cut -f1 ;;
      hdfs:*) printf "%-22s %s  " "$t" "$loc"; hdfs dfs -du -s -h "$loc" ;;
      *)      echo "$t: khong lay duoc vi tri (bang chua co?)" ;;
    esac
  done
}

cmd_hive() {
  command -v hive > /dev/null || { echo "Khong co lenh hive trong PATH"; return 1; }
  if ! hive -S -e "SHOW DATABASES" 2> /dev/null | grep -qx "$DB"; then
    echo "!! Hive KHONG thay database $DB."
    echo "   Nguyen nhan thuong gap: spark-sql dang dung metastore rieng (Derby trong $WORK), khong phai metastore cua Hive."
    echo "   Hoi TV1/TV5 cach tro Spark vao metastore cua Hive (hive-site.xml trong thu muc conf cua Spark)."
    return 1
  fi
  for f in hive_check q1_funnel_overall; do
    render "$HERE/queries/$f.sql" "$TMP/h_$f.sql" "$T_PQP" "$T_SF"
    hive -S --hiveconf hive.cli.print.header=true -f "$TMP/h_$f.sql" > "$OUT/h_$f.hive.out" 2> "$OUT/h_$f.hive.err"
    run_spark "$BASE_OPTS" "$TMP/h_$f.sql" > "$OUT/h_$f.spark.out" 2> "$OUT/h_$f.spark.err"
    if diff -q "$OUT/h_$f.hive.out" "$OUT/h_$f.spark.out" > /dev/null; then
      echo "$f: Hive va Spark KHOP"
    else
      echo "$f: Hive va Spark KHAC (thuong do mui gio timestamp):"
      diff "$OUT/h_$f.hive.out" "$OUT/h_$f.spark.out" | head -20
    fi
  done
}

case "${1:-}" in
  setup)   cmd_setup ;;
  build)   cmd_build ;;
  run)     cmd_run ;;
  summary) cmd_summary ;;
  sizes)   cmd_sizes ;;
  hive)    cmd_hive ;;
  all)     cmd_setup; cmd_build; cmd_run; cmd_sizes ;;
  clean)   rm -rf "$OUT" "$TMP"; echo "Da xoa $OUT va $TMP (bang trong database giu nguyen)" ;;
  *) echo "Dung: $0 setup | build | run | summary | sizes | hive | all | clean"; exit 1 ;;
esac
