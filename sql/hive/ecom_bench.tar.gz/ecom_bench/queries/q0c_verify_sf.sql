-- Kiểm tra hai cách dựng cho cùng kết quả (mismatched và missing_in_agg phải bằng 0)
SET spark.sql.session.timeZone = UTC;
USE __DB__;
SELECT COUNT(*) AS sessions_window,
  (SELECT COUNT(*) FROM __SF__) AS sessions_agg,
  SUM(CASE WHEN b.user_session IS NULL THEN 1 ELSE 0 END) AS missing_in_agg,
  SUM(CASE WHEN b.user_session IS NOT NULL AND (
        a.has_view_ordered <> b.has_view_ordered OR a.has_cart_ordered <> b.has_cart_ordered
     OR a.has_purchase_ordered <> b.has_purchase_ordered OR a.sessions_skip_stage <> b.sessions_skip_stage
     OR a.n_events <> b.n_events OR a.revenue <> b.revenue) THEN 1 ELSE 0 END) AS mismatched
FROM session_funnel_w a
LEFT JOIN __SF__ b ON a.user_session = b.user_session;
