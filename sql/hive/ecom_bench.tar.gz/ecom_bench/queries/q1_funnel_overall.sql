-- Q1: Funnel tổng thể, tuần tự View -> Cart -> Purchase (bản trước tối ưu: 3 lớp window)
SET spark.sql.session.timeZone = UTC;
USE __DB__;
WITH e1 AS (
  SELECT user_session, event_time, event_type,
    MIN(CASE WHEN event_type = 'view' THEN event_time END) OVER (PARTITION BY user_session) AS fv
  FROM __EVENTS__
  WHERE event_date BETWEEN DATE '__D1__' AND DATE '__D2__'
),
e2 AS (
  SELECT *, MIN(CASE WHEN event_type = 'cart' AND event_time >= fv THEN event_time END)
              OVER (PARTITION BY user_session) AS fc
  FROM e1
),
e3 AS (
  SELECT *, MIN(CASE WHEN event_type = 'purchase' AND event_time >= fc THEN event_time END)
              OVER (PARTITION BY user_session) AS fp
  FROM e2
),
sf AS (
  SELECT user_session, MIN(fv) AS fv, MIN(fc) AS fc, MIN(fp) AS fp,
    SUM(CASE WHEN event_type = 'cart'     THEN 1 ELSE 0 END) AS n_cart,
    SUM(CASE WHEN event_type = 'purchase' THEN 1 ELSE 0 END) AS n_purchase
  FROM e3
  GROUP BY user_session
),
cnt AS (
  SELECT
    SUM(CASE WHEN fv IS NOT NULL THEN 1 ELSE 0 END) AS S_view,
    SUM(CASE WHEN fc IS NOT NULL THEN 1 ELSE 0 END) AS S_cart,
    SUM(CASE WHEN fp IS NOT NULL THEN 1 ELSE 0 END) AS S_purchase,
    SUM(CASE WHEN (n_cart > 0 AND fc IS NULL) OR (n_purchase > 0 AND fp IS NULL) THEN 1 ELSE 0 END) AS sessions_skip_stage
  FROM sf
)
SELECT S_view, S_cart, S_purchase, sessions_skip_stage,
  ROUND(S_cart     / NULLIF(S_view, 0), 4) AS CR_view_to_cart,
  ROUND(S_purchase / NULLIF(S_cart, 0), 4) AS CR_cart_to_purchase,
  ROUND(S_purchase / NULLIF(S_view, 0), 4) AS CR_view_to_purchase
FROM cnt;
