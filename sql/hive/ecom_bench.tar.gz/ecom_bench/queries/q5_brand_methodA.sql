-- Q5: Funnel theo brand, Phương pháp A (cùng brand, đúng thứ tự). Bản trước tối ưu: 3 lớp window
SET spark.sql.session.timeZone = UTC;
USE __DB__;
WITH e1 AS (
  SELECT user_session, brand, event_time, event_type, price,
    MIN(CASE WHEN event_type = 'view' THEN event_time END) OVER (PARTITION BY user_session, brand) AS fv
  FROM __EVENTS__
  WHERE event_date BETWEEN DATE '__D1__' AND DATE '__D2__'
),
e2 AS (
  SELECT *, MIN(CASE WHEN event_type = 'cart' AND event_time >= fv THEN event_time END)
              OVER (PARTITION BY user_session, brand) AS fc
  FROM e1
),
e3 AS (
  SELECT *, MIN(CASE WHEN event_type = 'purchase' AND event_time >= fc THEN event_time END)
              OVER (PARTITION BY user_session, brand) AS fp
  FROM e2
),
sb AS (
  SELECT user_session, brand, MIN(fv) AS fv, MIN(fc) AS fc, MIN(fp) AS fp,
         SUM(CASE WHEN event_type = 'purchase' THEN price ELSE 0 END) AS revenue
  FROM e3
  GROUP BY user_session, brand
),
cnt AS (
  SELECT brand,
    SUM(CASE WHEN fv IS NOT NULL THEN 1 ELSE 0 END) AS S_view,
    SUM(CASE WHEN fc IS NOT NULL THEN 1 ELSE 0 END) AS S_cart,
    SUM(CASE WHEN fp IS NOT NULL THEN 1 ELSE 0 END) AS S_purchase,
    ROUND(SUM(revenue), 2) AS revenue
  FROM sb
  GROUP BY brand
)
SELECT brand, S_view, S_cart, S_purchase,
  ROUND(S_cart     / NULLIF(S_view, 0), 4) AS CR_view_to_cart,
  ROUND(S_purchase / NULLIF(S_cart, 0), 4) AS CR_cart_to_purchase,
  ROUND(S_purchase / NULLIF(S_view, 0), 4) AS CR_view_to_purchase,
  revenue
FROM cnt
ORDER BY S_view DESC, brand
LIMIT 15;
