-- Q1 (sau tối ưu): đọc bảng session_funnel đã dựng sẵn (Parquet)
SET spark.sql.session.timeZone = UTC;
USE __DB__;
SELECT S_view, S_cart, S_purchase, sessions_skip_stage,
  ROUND(S_cart     / NULLIF(S_view, 0), 4) AS CR_view_to_cart,
  ROUND(S_purchase / NULLIF(S_cart, 0), 4) AS CR_cart_to_purchase,
  ROUND(S_purchase / NULLIF(S_view, 0), 4) AS CR_view_to_purchase
FROM (
  SELECT
    SUM(CASE WHEN has_view_ordered     THEN 1 ELSE 0 END) AS S_view,
    SUM(CASE WHEN has_cart_ordered     THEN 1 ELSE 0 END) AS S_cart,
    SUM(CASE WHEN has_purchase_ordered THEN 1 ELSE 0 END) AS S_purchase,
    SUM(CASE WHEN sessions_skip_stage  THEN 1 ELSE 0 END) AS sessions_skip_stage
  FROM __SF__
  WHERE session_date BETWEEN DATE '__D1__' AND DATE '__D2__'
) t;
