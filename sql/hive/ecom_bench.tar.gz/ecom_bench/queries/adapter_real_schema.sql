-- Mẫu nối truy vấn với bảng thật của TV1 khi tên cột khác đặc tả.
-- Sửa vế trái "AS" cho đúng tên cột thật, rồi chạy bằng spark-sql -f.
-- Sau đó chạy benchmark với: T_PQP=events_real T_PQ=events_real T_CSV=events_real ./bench.sh run
USE __DB__;
CREATE OR REPLACE VIEW events_real AS
SELECT
  event_time                            AS event_time,        -- phải là TIMESTAMP UTC
  CAST(event_time AS DATE)              AS event_date,        -- hoặc cột partition thật
  user_session                          AS user_session,
  CAST(user_id AS STRING)               AS user_id,
  event_type                            AS event_type,
  CAST(product_id AS STRING)            AS product_id,
  COALESCE(category_code, 'unknown')    AS category,          -- đổi tên cột nếu khác
  COALESCE(brand, 'unknown')            AS brand,
  CAST(price AS DOUBLE)                 AS price
FROM your_db.your_events_clean_table;   -- thay bằng bảng TV1 giao
