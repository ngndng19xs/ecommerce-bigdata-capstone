-- Q3: Phân bố số sự kiện mỗi phiên (bản trước tối ưu: tính từ bảng sự kiện)
SET spark.sql.session.timeZone = UTC;
USE __DB__;
SELECT bucket, COUNT(*) AS sessions, ROUND(AVG(n), 2) AS avg_events_in_bucket, MAX(n) AS max_events
FROM (
  SELECT n,
    CASE WHEN n = 1 THEN '1 (bounce)' WHEN n <= 3 THEN '2-3' WHEN n <= 10 THEN '4-10' ELSE '11+' END AS bucket
  FROM (
    SELECT user_session, COUNT(*) AS n
    FROM __EVENTS__
    WHERE event_date BETWEEN DATE '__D1__' AND DATE '__D2__'
    GROUP BY user_session
  ) s
) b
GROUP BY bucket
ORDER BY bucket;
