-- Q5 (sau tối ưu): Phương pháp A bằng 1 phép gộp + collect_list + lọc mảng, bỏ 3 lớp window
SET spark.sql.session.timeZone = UTC;
USE __DB__;
WITH a AS (
  SELECT user_session, brand,
    MIN(CASE WHEN event_type = 'view' THEN event_time END)          AS fv,
    collect_list(CASE WHEN event_type = 'cart'     THEN event_time END) AS cart_times,
    collect_list(CASE WHEN event_type = 'purchase' THEN event_time END) AS purchase_times,
    SUM(CASE WHEN event_type = 'purchase' THEN price ELSE 0 END)    AS revenue
  FROM __EVENTS__
  WHERE event_date BETWEEN DATE '__D1__' AND DATE '__D2__'
  GROUP BY user_session, brand
),
b AS (
  SELECT *, array_min(filter(cart_times, x -> x >= fv)) AS fc FROM a
),
c AS (
  SELECT *, array_min(filter(purchase_times, y -> y >= fc)) AS fp FROM b
),
cnt AS (
  SELECT brand,
    SUM(CASE WHEN fv IS NOT NULL THEN 1 ELSE 0 END) AS S_view,
    SUM(CASE WHEN fc IS NOT NULL THEN 1 ELSE 0 END) AS S_cart,
    SUM(CASE WHEN fp IS NOT NULL THEN 1 ELSE 0 END) AS S_purchase,
    ROUND(SUM(revenue), 2) AS revenue
  FROM c
  GROUP BY brand
)
SELECT brand, S_view, S_cart, S_purchase,
  ROUND(S_cart     / NULLIF(S_view, 0), 4) AS CR_view_to_cart,
  ROUND(S_purchase / NULLIF(S_cart, 0), 4) AS CR_cart_to_purchase,
  ROUND(S_purchase / NULLIF(S_view, 0), 4) AS CR_view_to_purchase,
  revenue
FROM cnt
ORDER BY S_view DESC, brand
LIMIT 15;
