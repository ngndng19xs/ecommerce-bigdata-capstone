-- Q3 (sau tối ưu): từ bảng session_funnel đã dựng sẵn
SET spark.sql.session.timeZone = UTC;
USE __DB__;
SELECT bucket, COUNT(*) AS sessions, ROUND(AVG(n), 2) AS avg_events_in_bucket, MAX(n) AS max_events
FROM (
  SELECT n_events AS n,
    CASE WHEN n_events = 1 THEN '1 (bounce)' WHEN n_events <= 3 THEN '2-3' WHEN n_events <= 10 THEN '4-10' ELSE '11+' END AS bucket
  FROM __SF__
  WHERE session_date BETWEEN DATE '__D1__' AND DATE '__D2__'
) b
GROUP BY bucket
ORDER BY bucket;
