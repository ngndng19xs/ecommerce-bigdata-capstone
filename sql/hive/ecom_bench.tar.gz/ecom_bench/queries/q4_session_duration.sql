-- Q4: Phân bố thời lượng phiên, giây (bản trước tối ưu: tính từ bảng sự kiện)
SET spark.sql.session.timeZone = UTC;
USE __DB__;
SELECT bucket, COUNT(*) AS sessions, ROUND(AVG(d), 1) AS avg_sec, MAX(d) AS max_sec
FROM (
  SELECT d,
    CASE WHEN d = 0 THEN '0s' WHEN d <= 60 THEN '1-60s' WHEN d <= 300 THEN '61-300s'
         WHEN d <= 1800 THEN '301-1800s' ELSE '>1800s' END AS bucket
  FROM (
    SELECT user_session, CAST(MAX(event_time) AS BIGINT) - CAST(MIN(event_time) AS BIGINT) AS d
    FROM __EVENTS__
    WHERE event_date BETWEEN DATE '__D1__' AND DATE '__D2__'
    GROUP BY user_session
  ) s
) b
GROUP BY bucket
ORDER BY bucket;
