-- Dựng session_funnel_w bằng 3 lớp window (cách gốc, dùng làm chuẩn đối chiếu)
SET spark.sql.session.timeZone = UTC;
USE __DB__;
DROP TABLE IF EXISTS session_funnel_w;
CREATE TABLE session_funnel_w STORED AS PARQUET AS
WITH e1 AS (
  SELECT user_session, event_time, event_type, price,
    MIN(CASE WHEN event_type = 'view' THEN event_time END) OVER (PARTITION BY user_session) AS fv
  FROM __EVENTS__
),
e2 AS (
  SELECT *, MIN(CASE WHEN event_type = 'cart' AND event_time >= fv THEN event_time END)
              OVER (PARTITION BY user_session) AS fc
  FROM e1
),
e3 AS (
  SELECT *, MIN(CASE WHEN event_type = 'purchase' AND event_time >= fc THEN event_time END)
              OVER (PARTITION BY user_session) AS fp
  FROM e2
),
c AS (
  SELECT user_session,
    MIN(event_time) AS session_start_time, MAX(event_time) AS session_end_time,
    MIN(fv) AS first_view_time, MIN(fc) AS first_cart_after_view_time, MIN(fp) AS first_purchase_after_cart_time,
    COUNT(*) AS n_events,
    SUM(CASE WHEN event_type = 'view'             THEN 1 ELSE 0 END) AS n_view,
    SUM(CASE WHEN event_type = 'cart'             THEN 1 ELSE 0 END) AS n_cart,
    SUM(CASE WHEN event_type = 'remove_from_cart' THEN 1 ELSE 0 END) AS n_remove,
    SUM(CASE WHEN event_type = 'purchase'         THEN 1 ELSE 0 END) AS n_purchase,
    ROUND(SUM(CASE WHEN event_type = 'purchase' THEN price ELSE 0 END), 2) AS revenue
  FROM e3
  GROUP BY user_session
)
SELECT user_session, DATE(session_start_time) AS session_date, session_start_time, session_end_time,
  first_view_time, first_cart_after_view_time, first_purchase_after_cart_time,
  n_events, n_view, n_cart, n_remove, n_purchase, revenue,
  (first_view_time IS NOT NULL)                AS has_view_ordered,
  (first_cart_after_view_time IS NOT NULL)     AS has_cart_ordered,
  (first_purchase_after_cart_time IS NOT NULL) AS has_purchase_ordered,
  (n_view > 0)     AS has_view,
  (n_cart > 0)     AS has_cart,
  (n_purchase > 0) AS has_purchase,
  ((n_cart > 0 AND first_cart_after_view_time IS NULL)
    OR (n_purchase > 0 AND first_purchase_after_cart_time IS NULL)) AS sessions_skip_stage
FROM c;
