-- Kiểm tra chéo Hive và Spark trên cùng bảng Parquet (viết theo cú pháp chạy được cả hai)
USE __DB__;
SELECT COUNT(*) AS n_rows, COUNT(DISTINCT user_session) AS n_sessions,
       MIN(event_time) AS min_time, MAX(event_time) AS max_time
FROM __EVENTS__;
SELECT event_type, COUNT(*) AS n_events, ROUND(SUM(price), 2) AS revenue
FROM __EVENTS__
GROUP BY event_type
ORDER BY event_type;
SELECT event_date, COUNT(*) AS n_events
FROM __EVENTS__
WHERE event_date BETWEEN DATE '__D1__' AND DATE '__D2__'
GROUP BY event_date
ORDER BY event_date;
