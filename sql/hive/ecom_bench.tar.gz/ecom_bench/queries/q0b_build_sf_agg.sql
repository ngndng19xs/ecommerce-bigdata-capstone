-- Dựng bảng session_funnel (tối ưu): 1 phép gộp theo phiên, dùng collect_list và lọc mảng, không dùng window
SET spark.sql.session.timeZone = UTC;
USE __DB__;
DROP TABLE IF EXISTS __SF__;
CREATE TABLE __SF__ STORED AS PARQUET AS
WITH a AS (
  SELECT user_session,
    MIN(event_time) AS session_start_time, MAX(event_time) AS session_end_time,
    MIN(CASE WHEN event_type = 'view' THEN event_time END) AS first_view_time,
    collect_list(CASE WHEN event_type = 'cart'     THEN event_time END) AS cart_times,
    collect_list(CASE WHEN event_type = 'purchase' THEN event_time END) AS purchase_times,
    COUNT(*) AS n_events,
    SUM(CASE WHEN event_type = 'view'             THEN 1 ELSE 0 END) AS n_view,
    SUM(CASE WHEN event_type = 'cart'             THEN 1 ELSE 0 END) AS n_cart,
    SUM(CASE WHEN event_type = 'remove_from_cart' THEN 1 ELSE 0 END) AS n_remove,
    SUM(CASE WHEN event_type = 'purchase'         THEN 1 ELSE 0 END) AS n_purchase,
    ROUND(SUM(CASE WHEN event_type = 'purchase' THEN price ELSE 0 END), 2) AS revenue
  FROM __EVENTS__
  GROUP BY user_session
),
b AS (
  SELECT *, array_min(filter(cart_times, x -> x >= first_view_time)) AS first_cart_after_view_time FROM a
),
c AS (
  SELECT *, array_min(filter(purchase_times, y -> y >= first_cart_after_view_time)) AS first_purchase_after_cart_time FROM b
)
SELECT user_session, DATE(session_start_time) AS session_date, session_start_time, session_end_time,
  first_view_time, first_cart_after_view_time, first_purchase_after_cart_time,
  n_events, n_view, n_cart, n_remove, n_purchase, revenue,
  (first_view_time IS NOT NULL)                AS has_view_ordered,
  (first_cart_after_view_time IS NOT NULL)     AS has_cart_ordered,
  (first_purchase_after_cart_time IS NOT NULL) AS has_purchase_ordered,
  (n_view > 0)     AS has_view,
  (n_cart > 0)     AS has_cart,
  (n_purchase > 0) AS has_purchase,
  ((n_cart > 0 AND first_cart_after_view_time IS NULL)
    OR (n_purchase > 0 AND first_purchase_after_cart_time IS NULL)) AS sessions_skip_stage
FROM c;
