-- Q6: Truy vấn quét và gộp đơn giản theo brand (đo hiệu quả định dạng và phân vùng)
SET spark.sql.session.timeZone = UTC;
USE __DB__;
SELECT brand,
  SUM(CASE WHEN event_type = 'view'     THEN 1 ELSE 0 END) AS n_view,
  SUM(CASE WHEN event_type = 'cart'     THEN 1 ELSE 0 END) AS n_cart,
  SUM(CASE WHEN event_type = 'purchase' THEN 1 ELSE 0 END) AS n_purchase,
  ROUND(SUM(CASE WHEN event_type = 'purchase' THEN price ELSE 0 END), 2) AS revenue
FROM __EVENTS__
WHERE event_date BETWEEN DATE '__D1__' AND DATE '__D2__'
GROUP BY brand
ORDER BY revenue DESC, brand
LIMIT 15;
