-- Đo thời gian khởi động spark-sql (trừ ra khỏi các kết quả)
SELECT 1 AS ok;
