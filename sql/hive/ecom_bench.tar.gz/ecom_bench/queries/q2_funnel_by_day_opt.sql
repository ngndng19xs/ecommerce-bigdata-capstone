-- Q2 (sau tối ưu): từ bảng session_funnel đã dựng sẵn
SET spark.sql.session.timeZone = UTC;
USE __DB__;
SELECT session_date,
  SUM(CASE WHEN has_view_ordered     THEN 1 ELSE 0 END) AS S_view,
  SUM(CASE WHEN has_cart_ordered     THEN 1 ELSE 0 END) AS S_cart,
  SUM(CASE WHEN has_purchase_ordered THEN 1 ELSE 0 END) AS S_purchase,
  SUM(CASE WHEN sessions_skip_stage  THEN 1 ELSE 0 END) AS sessions_skip_stage
FROM __SF__
WHERE session_date BETWEEN DATE '__D1__' AND DATE '__D2__'
GROUP BY session_date
ORDER BY session_date;
